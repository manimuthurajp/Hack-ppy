<h1> Find the TEAM on social media : </h1>

[![Github](https://img.shields.io/badge/Github-fikrado-yellow?style=for-the-badge&logo=github)](https://github.com/fikrado)
[![Github](https://img.shields.io/badge/Facebook-fikrado-blue?style=for-the-badge&logo=facebook)](https://facebook.com/fikrado4048063)
[![Github](https://img.shields.io/badge/twitter-fikrado-aqua?style=for-the-badge&logo=twitter)](https://twitter.com/mr__yahye)

<img src="/Fikrado.jpg">

# TRY A TO CREAT VERTUAL LAB TO TEST MALWARES ONLINE WITH 
### https://replit.com
<img src="https://repl.it/public/images/dotcom_1.png">
